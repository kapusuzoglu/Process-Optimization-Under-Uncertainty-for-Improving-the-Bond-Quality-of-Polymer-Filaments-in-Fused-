%% Load the test data
clear; clc;
close all;
% rng(1)


% ======================================================================= %
% ======================================================================= %
% ===========================      GSA     ============================== %
% ======================================================================= %
% ======================================================================= %

% n: the number of input samples you'd like to use in each loop. For
% example, N can be 10000 but only 5000 are used in the analysis if you
% set n=5000
% N = 4;
% n = N^3-5*N;


KK = 273.15; % 0 Celcius in K

%Process Variables
%________________________________________________________________________
T_L = 215; %Extrusion temperature (�C)
T_E = 110; %Temperature of the envelope (�C)
v = 0.032; %Velocity of the extrusion head (m/sec)
w = 0.8e-3; % layer width [meters]
h = 0.7e-3; % layer height [meters]
L = 0.035; %Length of the filament (meters)
numLayers = 6;
number_filament = 15; 

% Process parameters
ProcessParam = [T_L, T_E, v, w, h, L];



% muN_C = log(C_mu/sqrt(1 + C_cov^2));
% sigmaN_C = sqrt(log(1 + C_cov^2));

% =======================         MC Samples      ======================= % 
N_Samples = 100;
% icdf of the parameters
U = lhsdesign(N_Samples, 3);

% Material Properties
%________________________________________________________________________
%Density (kg/m^3)
ro_mu = 1040; ro_cov = 0.05; % material A
ro_Samples = icdf('Normal', U(:,1), ro_mu, ro_cov*ro_mu);
%Specific heat (J/kg.K)
C_mu = 1290; C_cov = 0.05; % material A
C_Samples = icdf('Normal', U(:,2), C_mu, C_cov*C_mu);
% Heat transfer coefficient (loss of heat by natural convection)
h_conv_mu = 86; h_conv_cov = 0.05;
hconv_Samples = icdf('Normal', U(:,3), h_conv_mu, h_conv_cov*h_conv_mu);

% %Thermal contact conductances between
% h_cond_mu = 86; h_cond_cov = 0.1; % filament and adjacent filament & support
% hcond_Samples = icdf('Normal', U(:,4), h_cond_mu, h_cond_cov*h_cond_mu);

% Material parameters
% MaterialParam = [ro_Samples, C_Samples, hconv_Samples, hcond_Samples];
MaterialParam = [ro_Samples, C_Samples, hconv_Samples];




% n = 3;
% tic
% %% Double loop MC method
% First_order_double_loop   = DoubleLoopGSA_First(input_sample1, @Forman_Model_5000, n, Other_inputs);
% Total_effects_double_loop = DoubleLoopGSA_Total(input_sample1, @Forman_Model_5000, n, Other_inputs);
% toc




tic
% ======================================================================= %
%% Costa Model - Analytical
Matrix = ones(numLayers,number_filament);
x = L/2; % location of the cut in meters

% [Temp_C,time,limite] = FDM_TempModel_GSA(Matrix, x, ProcessParam, MaterialParam);

ticBytes(gcp);
parfor ii=1:N_Samples
    [Temp_C(ii,:)] = FDM_TempModel_GSA(Matrix, x, ProcessParam, MaterialParam(ii,:));
end
Temp_C=Temp_C(:,17:end);
tocBytes(gcp)

% % convert Celcius to Kelvin
% Temp = Temp_C + KK;
% 
% % Average two adjacent lines' temperatures to obtain interface temperatures
% % for each interface on that layer
% int_Temp = zeros(size(Temp,1),numFilaments-1);
% T_idx = zeros(1,numFilaments-1);
% for ii=2:numFilaments
%     T_idx(ii-1) = find(Temp(:,ii)<T_L+KK, 1, 'first');
%     int_Temp(T_idx(ii-1):end,ii-1) = (Temp(T_idx(ii-1):end,ii-1)+Temp(T_idx(ii-1):end,ii))/2;
% end
% 
% t_final=time(end);
% 
% 
% % Neck growth calculation using the temperature field from Costa model
% for rr=1:numFilaments-1 % loop over each interface for layer 1
%     num=size(int_Temp,1)-T_idx(rr)+1;
%     dt=t_final/num;
%     [bond3,t_bond3,theta3]=Neck_Growth_Model(int_Temp(T_idx(rr):end,rr),dt,t_final,w,h);
%     % method 2, more advisable
%     my_bonds = strcat('bond3_',num2str(rr));
%     variable.(my_bonds) = bond3;
%     my_bonds = strcat('t_bond3_',num2str(rr));
%     variable.(my_bonds) = t_bond3;
%     my_bonds = strcat('theta3_',num2str(rr));
%     variable.(my_bonds) = theta3;
% end

% ======================================================================= %
fprintf('\nAnalytical model is over: ');toc
fprintf('\n');


tic
%% Single loop methods
% CDF

% input_cdf = {[1 2 3 4], {'Normal','Normal','Normal','Normal'}, ...
%     {ro_mu,ro_cov*ro_mu}, {C_mu,C_cov*C_mu}, {h_conv_mu,h_conv_cov*h_conv_mu}, {h_cond_mu, h_cond_cov*h_cond_mu}};
input_cdf = {[1 2 3], {'Normal','Normal','Normal'}, ...
    {ro_mu,ro_cov*ro_mu}, {C_mu,C_cov*C_mu}, {h_conv_mu,h_conv_cov*h_conv_mu}};

SingleFirst_Index_Alg1 = SingleLoop_FirstOrder_Alg1(MaterialParam, ...
    Temp_C, ceil(sqrt(N_Samples)),  input_cdf);
fprintf('\n\nAlgorithm 1 completed: '); toc
fprintf('Sum of indices: %f\n', sum(SingleFirst_Index_Alg1(1,:)));
% fprintf('Sum of indices: %f \n', sum(SingleFirst_Index_Alg1(sum(Nf),:)));

SingleFirst_Index_Alg2 = SingleLoop_FirstOrder_Alg2(MaterialParam, ...
    Temp_C, ceil(sqrt(N_Samples)),  input_cdf);
fprintf('\nAlgorithm 2 completed: '); toc
fprintf('Sum of indices: %f \n', sum(SingleFirst_Index_Alg2(1,:)));
% fprintf('Sum of indices: %f \n', sum(SingleFirst_Index_Alg2(sum(Nf),:)));
fprintf('==========     Single Loop completed    ========\n');
toc




% N = 5000;



% % %% Latin Hypercube Samples
% % Mu = [C_mu,m_mu,Kc_mu,mu_a0,Fmax_mu,Fmax_mu*Fmax_cov]; % mean value
% % Std = Mu.*[C_cov m_cov Kc_cov,cov_a0,Fmax_cov,Fmax_cov]; % standard deviation
% % Sigma = diag(Std.^2); % standard deviation;
% % randAleo = rand(N, 4);
% % u11 = randAleo(:,1);
% % input_sample2 = [lhsnorm(Mu, Sigma, N), u11];
% % A = input_sample2;
% % randAleo = rand(N, 4);
% % u3 = randAleo(:,3);
% % B = [lhsnorm(Mu, Sigma, N), u3];
% 
% % % Saltelli
% % tic
% % First_order_Saltelli = Sen_FirstOrder_Saltelli(A, B, @Forman_Model_5000_TimeDependentGSA, Other_inputs);
% % % Total_effects_Saltelli = Sen_TotalEffect_Saltelli(A, B, @Forman_Model_5000, Other_inputs);
% % % fprintf('Sum of indices: %f \n', sum(First_order_Saltelli));
% % fprintf('==========     Saltelli completed    ======== >>> ');toc
% % 
% % tic
% % % Sobol' method
% % First_order_Sobol = Sen_FirstOrder_Sobol_07(A, B, @Forman_Model_TimeDependentGSA_MaxLoad, Other_inputs);
% % % fprintf('Sum of indices: %f \n', sum(First_order_Sobol));
% % fprintf('==========     Sobol completed    ======== >>> ');toc
% 
% tic
% % improved FAST based on RBD
% % lognormal mu and std
% % Mu = [muN_C,muN_m,muN_Kc,mu_a0,Fmax_mu,Fmin_mu,Fmax_mu*Fmax_cov,Fmin_mu*Fmin_cov,0,0]; % mean value
% % Std = [sigmaN_C,sigmaN_m,sigmaN_Kc,mu_a0*cov_a0,Fmax_mu*Fmax_cov,Fmin_mu*Fmin_cov,Fmax_mu*Fmax_cov*Fmax_cov,Fmin_mu*Fmin_cov*Fmin_cov,1,1]; % standard deviation
% Mu = [muN_C,muN_m,muN_Kc,mu_a0,A_maxLB,A_maxSLB,0]; % mean value
% Std = [sigmaN_C,sigmaN_m,sigmaN_Kc,mu_a0*cov_a0,A_maxUB,A_maxSUB,1]; % standard deviation
% k = size(Mu, 2);
% other_inputs = [Mu, Std, Other_inputs];
% First_order_FAST = Sen_FirstOrder_RBD(N, k, @Forman_Model_RBD_UniformMaxLoad,other_inputs);
% fprintf('\n Improved FAST completed: '); toc

t=1:size(SingleFirst_Index_Alg1,1);


% plot
% fname = 'C:\Users\kapusub\Documents\MATLAB\TermPaper\GSA_Prognosis032';
figure
set(0,'DefaultLineLineWidth',2)
% plot(First_order_double_loop, 'r+');
% hold on;
plot(t,SingleFirst_Index_Alg1(:,1), 'm-'); hold on;
plot(t,SingleFirst_Index_Alg2(:,1), 'b--'); hold on;
% plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% plot(t,First_order_FAST(:,1), 'r-.'); hold on;
% plot(t,First_order_Sobol(2:end,1), 'k:');
ylim([0, 1]);
xlabel('Time (s)', 'FontName', 'Times New Roman', ...
'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
ylabel('First-order index', 'FontName', 'Times New Roman', ...
'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
'FontSize',10,'Interpreter', 'LaTeX')
title('$\rho$','FontName', 'Times New Roman', ...
'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
set(gcf, 'Position',  [200, 300, 900, 600])
set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_1'), 'pdf') %Save figure


% plot
% fname = 'C:\Users\kapusub\Documents\MATLAB\TermPaper\GSA_Prognosis032';
figure
set(0,'DefaultLineLineWidth',2)
% plot(First_order_double_loop, 'r+');
% hold on;
plot(t,SingleFirst_Index_Alg1(:,2), 'm-'); hold on;
plot(t,SingleFirst_Index_Alg2(:,2), 'b--'); hold on;
% plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% plot(t,First_order_FAST(:,1), 'r-.'); hold on;
% plot(t,First_order_Sobol(2:end,1), 'k:');
ylim([0, 1]);
xlabel('Time (s)', 'FontName', 'Times New Roman', ...
'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
ylabel('First-order index', 'FontName', 'Times New Roman', ...
'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
'FontSize',10,'Interpreter', 'LaTeX')
title('C','FontName', 'Times New Roman', ...
'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
set(gcf, 'Position',  [200, 300, 900, 600])
set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_1'), 'pdf') %Save figure


% plot
% fname = 'C:\Users\kapusub\Documents\MATLAB\TermPaper\GSA_Prognosis032';
figure
set(0,'DefaultLineLineWidth',2)
% plot(First_order_double_loop, 'r+');
% hold on;
plot(t,SingleFirst_Index_Alg1(:,3), 'm-'); hold on;
plot(t,SingleFirst_Index_Alg2(:,3), 'b--'); hold on;
% plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% plot(t,First_order_FAST(:,1), 'r-.'); hold on;
% plot(t,First_order_Sobol(2:end,1), 'k:');
ylim([0, 1]);
xlabel('Time (s)', 'FontName', 'Times New Roman', ...
'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
ylabel('First-order index', 'FontName', 'Times New Roman', ...
'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
'FontSize',10,'Interpreter', 'LaTeX')
title('$h_{conv}$','FontName', 'Times New Roman', ...
'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
set(gcf, 'Position',  [200, 300, 900, 600])
set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_1'), 'pdf') %Save figure


% 
% %% plot
% fname = 'C:\Users\kapusub\Documents\MATLAB\TermPaper\GSA_Prognosis032';
% figure
% set(0,'DefaultLineLineWidth',2)
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,1), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,1), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,1), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,1), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('C','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_1'), 'pdf') %Save figure
% %% plot
% figure
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,2), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,2), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,2), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,2), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,2), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('m','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_2'), 'pdf') %Save figure
% %% plot
% figure
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,3), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,3), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,3), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,3), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,3), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('$K_c$','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_3'), 'pdf') %Save figure
% 
% 
% figure
% set(0,'DefaultLineLineWidth',2)
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,4), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,4), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,4), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,4), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('$a_0$','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_4'), 'pdf') %Save figure
% 
% 
% 
% 
% figure
% set(0,'DefaultLineLineWidth',2)
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,5), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,5), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,5), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,5), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('$\mu_{F_{max1}}$','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_5'), 'pdf') %Save figure
% 
% 
% figure
% set(0,'DefaultLineLineWidth',2)
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,6), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,6), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,6), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,5), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('$\mu_{F_{max2}}$','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_6'), 'pdf') %Save figure
% 
% 
% figure
% set(0,'DefaultLineLineWidth',2)
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,7), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,7), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,7), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,5), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('$\mu_{F_{max3}}$','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_7'), 'pdf') %Save figure
% 
% 
% figure
% set(0,'DefaultLineLineWidth',2)
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,8), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,8), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,8), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,7), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('$\sigma_{F_{max1}}$','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_8'), 'pdf') %Save figure
% 
% figure
% set(0,'DefaultLineLineWidth',2)
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,9), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,9), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,9), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,7), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('$\sigma_{F_{max2}}$','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_9'), 'pdf') %Save figure
% 
% figure
% set(0,'DefaultLineLineWidth',2)
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,10), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,10), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,10), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,7), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('$\sigma_{F_{max3}}$','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_10'), 'pdf') %Save figure
% 
% 
% 
% figure
% set(0,'DefaultLineLineWidth',2)
% % plot(First_order_double_loop, 'r+');
% % hold on;
% plot(t,SingleFirst_Index_Alg1(:,11), 'm-'); hold on;
% plot(t,SingleFirst_Index_Alg2(:,11), 'b--'); hold on;
% % plot(t,First_order_Saltelli(2:end,1), 'c.-.'); hold on;
% % plot(t,First_order_FAST(:,11), 'r-.'); hold on;
% % plot(t,First_order_Sobol(2:end,9), 'k:');
% ylim([0, 1]);
% xlabel('Time (Number of cycles)', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% ylabel('First-order index', 'FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% legend({'Single loop Algorithm 1', 'Single loop Algorithm 2'},'location', 'northwest', 'FontName', 'Times New Roman', ...
% 'FontSize',10,'Interpreter', 'LaTeX')
% title('$U_{F_{max}}$','FontName', 'Times New Roman', ...
% 'FontSize',16,'Color','k', 'Interpreter', 'LaTeX')
% set(gcf, 'Position',  [200, 300, 900, 600])
% set(gcf, 'PaperPosition', [0 0 7 5]); %Position plot at left hand corner with width 5 and height 5.
% set(gcf, 'PaperSize', [7 5]); %Set the paper to have width 5 and height 5.
% saveas(gcf, fullfile(fname,'\Fig_UniMaxF_3_11'), 'pdf') %Save figure
% 
% 
