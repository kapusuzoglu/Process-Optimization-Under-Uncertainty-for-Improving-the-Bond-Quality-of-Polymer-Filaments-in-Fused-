function [a_f] = ...
         Forman_Model_RBD(input, other_inputs)
     
Mu = other_inputs{1};
Std = other_inputs{2};
%Other_inputs=other_inputs(1,3:8);
% C = logninv(input(:, 1), Mu(1), Std(1));
% m = logninv(input(:, 2), Mu(2), Std(2));
% Kc = logninv(input(:, 3), Mu(3), Std(3));

% with a0
Other_inputs=other_inputs(1,3:7);
C = logninv(input(:, 1), Mu(1), Std(1));
m = logninv(input(:, 2), Mu(2), Std(2));
Kc = logninv(input(:, 3), Mu(3), Std(3));
a0 = norminv(input(:, 4), Mu(4), Std(4));

a_f = Forman_Model_TimeDependentGSA_a0([C,m,Kc,a0], Other_inputs );

end